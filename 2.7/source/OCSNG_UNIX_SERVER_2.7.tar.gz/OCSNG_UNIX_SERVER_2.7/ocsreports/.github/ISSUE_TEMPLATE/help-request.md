---
name: Help request
about: Need help with OCS Inventory ? Click here
title: "[HELP]"
labels: question
assignees: charleneauger, gillesdubois, RudyLaurent

---

**BEFORE PUBLISHING**
PLEASE, take a look at our wiki before posting your question : https://wiki.ocsinventory-ng.org/

**Describe the bug**
A clear and concise description of what your question is

**Screenshots**
If applicable, add screenshots to help explain your problem.
