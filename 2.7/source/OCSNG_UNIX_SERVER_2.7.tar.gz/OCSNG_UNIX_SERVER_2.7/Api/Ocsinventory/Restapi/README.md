Prerequisites :

Apache::DBI
Mojo::Json
Mojolicious::Lite
Swagger
Mojolicious
Plack
Switch
